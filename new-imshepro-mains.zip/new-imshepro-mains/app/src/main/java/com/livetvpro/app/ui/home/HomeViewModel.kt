package com.livetvpro.app.ui.home

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.livetvpro.app.data.models.Category
import com.livetvpro.app.data.repository.CategoryRepository
import com.livetvpro.app.utils.RetryViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val categoryRepository: CategoryRepository
) : RetryViewModel() {

    private val _categories = MutableLiveData<List<Category>>()
    val categories: LiveData<List<Category>> = _categories

    private val _filteredCategories = MutableLiveData<List<Category>>()
    val filteredCategories: LiveData<List<Category>> = _filteredCategories

    private var currentSearchQuery = ""

    init {
        loadData()
    }

    override fun loadData() {
        viewModelScope.launch {
            try {
                startLoading()
                
                val categories = categoryRepository.getCategories()
                
                _categories.value = categories
                searchCategories(currentSearchQuery)
                
                finishLoading(dataIsEmpty = categories.isEmpty())
            } catch (e: Exception) {
                _categories.value = emptyList()
                _filteredCategories.value = emptyList()
                
                finishLoading(dataIsEmpty = true, error = e)
            }
        }
    }

    // FIXED: Override onResume() instead to prevent auto-reload when coming back from player
    // This prevents unnecessary reloading that would lose your scroll position and reload data
    override fun onResume() {
        // Do nothing - don't reload data when resuming
        // Data is already loaded and cached in memory
    }

    fun searchCategories(query: String) {
        try {
            currentSearchQuery = query
            val allCategories = _categories.value ?: emptyList()

            if (query.isBlank()) {
                _filteredCategories.value = allCategories
            } else {
                _filteredCategories.value = allCategories.filter {
                    it.name.contains(query, ignoreCase = true) ||
                    it.slug.contains(query, ignoreCase = true)
                }
            }
        } catch (e: Exception) {
        }
    }
}
